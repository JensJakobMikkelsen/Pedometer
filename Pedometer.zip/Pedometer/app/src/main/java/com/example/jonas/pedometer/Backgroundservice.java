package com.example.jonas.pedometer;



import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Binder;

import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;


import java.net.URL;


public class Backgroundservice extends Service  implements SensorEventListener {


    public static final String EXTRA_TASK_RESULT = "result";
    private static final String LOG = "BG_SERVICE";
    private boolean started = false;
    private IBinder binder = new BackgroundServiceBinder();
    private String TAG = Backgroundservice.class.getSimpleName();
    int i;

    SensorManager sensorManager;
    public Sensor counterSensor;

    public Backgroundservice() {

    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }


    @Override
    public void onCreate(){
        super.onCreate();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        counterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        sensorManager.registerListener(this, counterSensor, sensorManager.SENSOR_DELAY_FASTEST);

        Log.d(TAG, "QuoteService Started");

    }

    private void sendInitializationMessage(int i)
    {
        Log.d("sender", "Initialization_done");
        Intent intent = new Intent("pedoService");
        intent.putExtra("message", "update");
        intent.putExtra("steps", i);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    public void onSensorChanged(SensorEvent event) {
        i++;
        sendInitializationMessage(i);

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    // Method taken directly from lecture example code "servicesDemo"
    @Override
    public void onDestroy() {
        started = false;
        Log.d(LOG,"Background service destroyed");
        super.onDestroy();
    }

    public class BackgroundServiceBinder extends Binder {
        public   Backgroundservice getService() {
            // Return this instance of LocalService so clients can call public methods
            return Backgroundservice.this;
        }
    }


}

