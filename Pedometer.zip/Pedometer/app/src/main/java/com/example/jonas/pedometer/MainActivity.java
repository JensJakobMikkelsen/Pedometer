package com.example.jonas.pedometer;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


// https://www.youtube.com/watch?v=CNGMWnmldaU
//public class MainActivity extends AppCompatActivity implements SensorEventListener {


public class MainActivity extends AppCompatActivity{

    TextView TvSteps, TvSteps2;
    Button BtnStart2,BtnStop;

    private String TAG = MainActivity.class.getSimpleName();

    boolean running = false;
    int i;


    Backgroundservice mService;
    Intent bound;
    boolean mBound = false;

    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            Backgroundservice.LocalBinder binder = (Backgroundservice.LocalBinder) service;
            mService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get an instance of the SensorManager

        SensorManager sensorManager;
        Sensor counterSensor;

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        counterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);

        TvSteps = (TextView) findViewById(R.id.tv_steps);
        TvSteps2 = (TextView) findViewById(R.id.tv_steps2);
        BtnStart2 = (Button) findViewById(R.id.btn_start2);
        BtnStop = (Button) findViewById(R.id.btn_stop);

        BtnStart2.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View arg0) {

                if(!mBound) {
                    bound = new Intent(getApplicationContext(), Backgroundservice.class);
                    bindService(bound, mConnection, Context.BIND_AUTO_CREATE);
                }

                //Log.d(TAG, "registering receivers");
                //IntentFilter filter = new IntentFilter();
                //  filter.addAction(BackgroundService.BROADCAST_BACKGROUND_SERVICE_RESULT);

            }
        });

        BtnStop.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if(mBound) {
                    unbindService(mConnection);
                    mBound = false;
                    Log.d(TAG,"Service unbindService");
                }
            }
        });



        if(savedInstanceState != null)
        {
            i = savedInstanceState.getInt("time");
            running = savedInstanceState.getBoolean("running");
            TvSteps2.setText(String.valueOf(i));

        }

    }
    void bind()
    {
        //Setting up and binding to service
        bound = new Intent(this, Backgroundservice.class);
        //startService(bindIntent);
        //This also sets up components
        bindService(bound, mConnection, Context.BIND_AUTO_CREATE);
    }

    public void onSaveInstanceState(Bundle outState) {

        outState.putInt("time",i);
        outState.putBoolean("running",running);
        super.onSaveInstanceState(outState);
    }

    private BroadcastReceiver onBackgroundServiceResult = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String jsonStr = intent.getStringExtra(Backgroundservice.EXTRA_TASK_RESULT);
            Log.d(TAG, "Updating stocks..." +jsonStr );
            String message = intent.getStringExtra("message");

            int steps = 0;
            String steps_s = "";
            if(message == "updated")
            {
                steps = intent.getIntExtra("steps", 0);
            }

            try
            {
                   steps_s = Integer.toString(steps);
            }
            catch(NumberFormatException nfe)
            {

            }

            TvSteps2 = (TextView) findViewById(R.id.tv_steps2);
            TvSteps2.setText(steps_s);
/*
            String results = intent.getStringExtra(Backgroundservice.EXTRA_TASK_RESULT);

            TvSteps2 = (TextView) findViewById(R.id.tv_steps2);
            TvSteps2.setText(results);
*/
        }

    };

    @Override
    protected void onPause()
    {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(onBackgroundServiceResult);
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "registering receivers");
        IntentFilter filter = new IntentFilter();
        //  filter.addAction(BackgroundService.BROADCAST_BACKGROUND_SERVICE_RESULT);
        LocalBroadcastManager.getInstance(this).registerReceiver(onBackgroundServiceResult, filter);
    }

    /*
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
*/

    @Override
    protected void onResume() {
        super.onResume();

        LocalBroadcastManager.getInstance(MainActivity.this).registerReceiver(onBackgroundServiceResult, new IntentFilter("Pedoservice"));
        //   if(counterSensor != null)

    }
}